class SnapshotManager: pass
