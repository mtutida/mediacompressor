from app.ancillary.logging_service import LoggingService


class ApplicationContext:

    def __init__(self):

        # services
        self.logger = LoggingService()

        # placeholders para serviços futuros
        self.scheduler = None
        self.engine = None
        